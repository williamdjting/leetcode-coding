#include "main.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX 256

char *builtInCommands[4] = {"exit", "log", "print",
                            "theme"}; // char array of built in commands

typedef struct {
  char *command;
  char **arguments;
} Filter;

typedef struct {
  char *name;
  char *value;
} EnvVar;

// create an array of structs with size MAX and define int size

/*
// below is an example - log command needs to have a struct passed in as a
parameter so it may need its own separate command that is not named
'builtInSystemCall' function

struct Person {
    char name[50];
    int age;
};

typedef struct {
    char *name;
    struct tm time;
    int value;
} Command;
// create an array of structs with size MAX and define int size

// below is an example - log command needs to have a struct passed in as a
parameter so it may need its own separate command that is not named
'builtInSystemCall' function



struct Person {
    char name[50];
    int age;
};


void printPeople(struct Person people[], int size) {
    for (int i = 0; i < size; i++) {
        printf("Person %d:\n", i + 1);
        printf("Name: %s\n", people[i].name);
        printf("Age: %d\n", people[i].age);
        printf("\n");
    }
}

int main() {
    struct Person people[3] = {
        {"John", 25},
        {"Alice", 30},
        {"Bob", 40}
    };

    int size = sizeof(people) / sizeof(people[0]);

    printPeople(people, size);

    return 0;
}

*/

char **splitString(const char *input) {
  char temp[MAX];
  strcpy(temp, input);

  char *token = strtok(temp, " ");
  char **words = (char **)malloc(MAX * sizeof(char *));

  for (int i = 0; token != NULL && i < MAX; i++) {
    words[i] = strdup(token);
    token = strtok(NULL, " ");
  }

  return words;
}
const char *print(char *strptr) {
  printf("%s", strptr);
  return "\0";
}

// int getLineFromShell(){

// }

int scriptMode(const char *command) {

  // need to wrap function in a while loop?

  // read txt.file then getLineFromShell() for each line in file;

  // grep to pull the token that is the commands

  /*loop through the commands , if anyone of them contain an array element from
   * builtInCommands array then run builtInSystemCall function else run
   * notBuiltInSystemCall function */

  // builtInSystemCall();

  // if built in command, pass arguments into built in command system call
  // function
  // notbuiltInSystemCall();

  // else, run NOT built in command system call function
  return 0;
};

int interactiveMode(const char *command) {

  // grep to pull the token that is the commands

  /*loop through the commands , if anyone of them contain an array element from
   * builtInCommands array then run builtInSystemCall function else run
   * notBuiltInSystemCall function */

  // builtInSystemCall();

  // getLineFromShell();

  // grep to pull the token that is the command

  // function exits when user does what?

  // if built in command, pass arguments into built in command system call
  // function

  // else, run NOT built in command system call function
  // notbuiltInSystemCall(*command);
  return 0;
};

int main(int ac, char **argv) {
  // FILE *fptr;
  // fptr = fopen("myscript.txt","r");
  // switch  (/* if there is a textfile run script mode, else run interactive
  // mode? */ )
  // {
  // case 1: // if there is a textfile run script mode
  // if(fptr == NULL)
  //     scriptMode();

  //     break;
  // else
  // default:
  //     interactiveMode();
  //     break;
  // }

  char *prompt = "cshell$ ";
  char *input = "";
  size_t n = 0;
  Filter line;
  char **words = "";

  EnvVar varibles[MAX];
  EnvVar VarInput;
  // printf("var test:%s\n",varibles[1].value);
  while (strcmp(input, "exit")) {
    printf("%s", prompt);
    getline(&input, &n, stdin);
    input[strcspn(input, "\n")] = '\0';
    words = splitString(input);
    line.command = words[0];
    line.arguments = words + 1;
    // notBuiltInSystemCall(input);
    for (int i = 0; builtInCommands[i] != NULL; i++) {
      if (strcmp(input, builtInCommands[i]) == 0) {
        builtInSystemCall(input);
        break;
      } else {
        notBuiltInSystemCall(input);
        break;
      }
    }
    printf("this is line.command %s \n", line.command);
    printf("TEST2, command: %s, Argv: %s \n", line.command, line.arguments[0]);
  }
  // printf("Bye!");

  for (int i = 0; words[i] != NULL; i++) {
    printf("%s \n", words[i]); // each word in the input separated as tokens
  }

  // printf("this is line.arguments %s \n", line.arguments);
  printf("TEST: %s ", words[1]);

  // print(input + 6);
  // printf("%s\n",lineptr);

  free(input);
  // getLineFromShell(); // leaving in main for testing but this should go into
  // each respective mode functions

  return 0;
}