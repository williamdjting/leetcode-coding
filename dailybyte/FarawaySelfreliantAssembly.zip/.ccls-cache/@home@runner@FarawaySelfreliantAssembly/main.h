// insert our helper functions here
// main functions for interactive and script modes stay in main.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

void printThis(char *strptr) { printf("%s", strptr); }

// below is used for actualy system call's
// int exitStatus = system(command);
//   // from chatgpt
//   if (exitStatus == -1) {
//       perror("System call failed");
//       exit(1);
//   } else {
//       printf("Command executed with exit status: %d\n", exitStatus);
//   }


void notBuiltInSystemCall(
    char *command /*the token that we call for built in system call*/) {
  // pass in the command to be executed
  printf("we are in notbuiltinsystemcall execution %s\n", command);
  pid_t pid = fork();

  if (pid < 0) {
    // error
    printf("line 30 - main.h forking failed\n");
    return 1; 
  }
  else if (pid == 0 ) {
    // executing command
    execlp(command,command,NULL);

    // command execution failed

    printf("line 39 - main.h command not found\n");
    exit(0);
    
  }

  else {
    // wait for child process to finish
    wait(NULL);
  }


  
  // OLD CODE BELOW
  
  // printf("Hello there (pid:%d)\n",
  //        (int)getpid()); // taken from 4.1 process 3 slides
  // pid_t pid = fork();

  // if (pid < 0) {
  //   perror("Fork failed\n");
  //   exit(1);
  // }

  // else if (pid == 0) {
  //   // run child process
  //   execl("/bin/sh", "sh", "-c", command, (char *)NULL);
  //   printf("I am child (pid:%d)\n", (int)getpid());

  //   perror("Exec failed");
  //   exit(EXIT_FAILURE);

  //   // else runs but doesn't print out the child process pid == 0 function, need
  //   // to use pipe to get the output of the child process apparently, look into
  //   // this
  // } else {
  //   printf("I am parent of %d (pid:%d)\n", pid, (int)getpid());
  //   // line 42-50 from chatgpt
  //   int status;
  //   waitpid(pid, &status, 0);
  //   if (WIFEXITED(status)) {
  //     int exit_status = WEXITSTATUS(status);
  //     printf("Child process exited with status: %d\n", exit_status);
  //   } else {
  //     printf("Child process exited abnormally\n");
  //   }

  //   exit(1);
  // }


  
}

// below are the built in commands 'exit' , 'log', 'print', 'theme'

void exitCommand() {
  printf("exit command\n");
  printf("Bye!\n");
  exit(0);
}

void logCommand() {
  printf("log command\n");
  const char *command = "history";
  // make the log struct and implement the history of our struct in main.c and
  // parse through it here and print it out
  int exitStatus = system(command);

  if (exitStatus == -1) {
    perror("System call failed");
    exit(1);
  } else {
    printf("Command executed with exit status: %d\n", exitStatus);
  }
}

void printCommand(char *command) {
  // have to loop through the all the commands and print them out
  printf("print %s command\n", command);
  printf("print\n");
}

void themeCommand(char *colour) {
  char *colourOptions[3] = {"red", "green", "blue"};

  if (strcmp(colour, colourOptions[0]) != 0) {
    printf("red theme");
  } else if (strcmp(colour, colourOptions[1]) != 0) {
    printf("green theme");
  } else if (strcmp(colour, colourOptions[2]) != 0) {
    printf("blue theme");
  } else {
    printf("colour not found");
  }
}

void builtInSystemCall(char *command) {

  char exitString[] = "exit";
  char logString[] = "log";
  char printString[] = "print";
  char themeString[] = "theme";

  if (command == NULL) {
    printf("No command entered\n");
    exit(1);
  }

  else if (command != NULL) {
    if (strcmp(command, exitString) == 0) {
      exitCommand();
    } else if (strcmp(command, logString) == 0) {
      logCommand();
    } else if (strcmp(command, printString) == 0) {
      printCommand(command);
    } else if (strcmp(command, themeString) == 0) {
      themeCommand(command);
    } 
  }
}